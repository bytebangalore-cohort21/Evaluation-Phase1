from model_mvc import Election_Data

def showWinner(Year):
    print(Year)
    year = Year
    winner = Election_Data.getWinner(year)
    print('The winner of the election is: %s' %winner)

def startView():
    print ('Which year would you want to see the election results for?')