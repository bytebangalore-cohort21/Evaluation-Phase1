from model_mvc import Election_Data
from view_mvc import *

def start():
    startView()
    year=input()
    showWinner(year)

if __name__ == "__main__":
    #running controller function
    start()
