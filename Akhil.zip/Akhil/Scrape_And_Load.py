import pandas as pd
from bs4 import BeautifulSoup
import lxml.html as lh
import requests
import re
import sqlite3

##Web Scraping to retreive data from Wikipedia
page = requests.get("https://en.wikipedia.org/wiki/Elections_in_India")
soup = BeautifulSoup(page.content,'html.parser')

##Choosing the correct table
table_names = soup.find_all('table',class_='wikitable')
ls_table = table_names[5]

#Converting the table data into an HTML
ls_string = str(ls_table)
start_str = '<!DOCTYPE html>  <html> <body>'
end_str = '</body> </html>'
full_str = start_str + ls_string + end_str
doc = lh.fromstring(full_str)
tr_elements = doc.xpath('//tr')

#Defining Header Values
final_frame_top = ["","","","First","First","First","Second","Second","Second","Third","Third","Third"]

col=[]
i=0

for t in tr_elements[1]:
    i=i+1

    name = t.text_content()
    correct_name = final_frame_top[i-1]+'_'+ name
    col.append((correct_name.rstrip(),[]))

#Assigning Values in collection
for j in range(2,len(tr_elements)):
    T = tr_elements[j]

    i=0

    for t in T.iterchildren():
        data = t.text_content()
        re.sub("[\(\[].*?[\)\]]", "", data)
        col[i][1].append(data.rstrip())
        i=i+1

#Converting into a dataframe and renaming the header values
Dict={title:column for (title,column) in col}
df=pd.DataFrame(Dict)
df.columns= ['Year','Election','Total_Seats','First_Party','First_Seats','First_Pct_Votes','Second_Party','Second_Seats','Second_Pct_Votes','Third_Party','Third_Seats','Third_Pct_Votes']

#Loading data from Dataframe into an SQL Lite Database
conn = sqlite3.connect("C:\\Akhil\\Workspace\\election_data.db")
df.to_sql('new_election_data', conn, dtype={
    'Year':'VARCHAR(100)',
    'Election':'VARCHAR(100)',
    'Total_seats':'VARCHAR(100)',
    'First_Party':'VARCHAR(100)',
    'First_Seats':'VARCHAR(100)',
    'First_Pct_votes':'VARCHAR(100)',
    'Second_Party':'VARCHAR(100)',
    'Second_Seats':'VARCHAR(100)',
    'Second_Pct_votes':'VARCHAR(100)',
    'Third_Party':'VARCHAR(100)',
    'Third_Seats':'VARCHAR(100)',
    'Third_Pct_votes':'VARCHAR(100)'
})
conn.commit()