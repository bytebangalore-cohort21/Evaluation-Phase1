import sqlite3

class Election_Data(object):

    def __init__(self, Year, Election, Total_seats, First_Party, First_Seats, First_Pct_votes,Second_Party,Second_Seats,Second_Pct_votes,Third_Party,Third_Seats,Third_Pct_votes):
        self.Year = Year
        self.Election = Election
        self.Total_seats = Total_seats
        self.First_Party = First_Party
        self.First_Seats = First_Seats
        self.First_Pct_votes = First_Pct_votes
        self.Second_Party = Second_Party
        self.Second_Seats = Second_Seats
        self.Second_Pct_votes = Second_Pct_votes
        self.Third_Party = Third_Party
        self.Third_Seats = Third_Seats
        self.Third_Pct_votes = Third_Pct_votes

    def getWinner(Year):
        conn = sqlite3.connect("C:\\Akhil\\Workspace\\election_data.db")
        cur = conn.cursor()
        cur.execute("select First_Party from new_election_data where year ='%s';"%Year)
        results = cur.fetchall()
        return results